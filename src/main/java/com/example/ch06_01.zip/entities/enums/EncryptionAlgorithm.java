package com.example.ch06_01.entities.enums;

/**
 * description    :
 * ===========================================================
 * DATE              AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2024-01-03        koiw1       최초 생성
 */
public enum EncryptionAlgorithm {
    BCRYPT, SCRYPT
}
